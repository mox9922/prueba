<?php
defined('BASEPATH') OR exit('No direct script access allowed');


//project data
$config['project']['tiulo'] = "Gestion Monserrat";


//project email SMTP
$config['project']['email']['ticket']['from_name'] = 'Vistas de Monserrat';
$config['project']['email']['ticket']['from'] = 'sistemas-cr@codosat.com';
$config['project']['email']['ticket']['servidor'] = 'smtp.office365.com';
$config['project']['email']['ticket']['port']     = '587';
$config['project']['email']['ticket']['username'] = 'sistemas-cr@codosat.com';
$config['project']['email']['ticket']['password'] = '1qa2ws3ed4rf5tG6y1!';
$config['project']['email']['ticket']['secure']   = 'ssl';
$config['project']['email']['ticket']['logo']     = 'logo';